import React, { Component } from "react";
import Product from "./Componenets/Product";
import "./App.css";
import data from "./data.json";
import Cart from "./Componenets/Cart";

class App extends Component {
  state = { productList: [], shoppingCart: [] };
  updatedMobileList = [];
  componentWillMount() {
    this.updatedMobileList = data.filter(mobile => mobile.isPublished);
    this.setState({ productList: this.updatedMobileList });
  }

  addToCart = mobile => {
    console.log(mobile);
    this.updatedMobileList = this.state.productList.filter(
      x => x.productName !== mobile.productName
    );
    let cart = [...this.state.shoppingCart, mobile];
    //const updatedShoppingCart= data.filter(mobile => mobile.productName===name);
    this.setState({ productList: this.updatedMobileList, shoppingCart: cart });
  };

  removeProduct = mobile => {
    this.updatedMobileList = [...this.state.productList, mobile];
    let cart = this.state.shoppingCart.filter(
      x => x.productName !== mobile.productName
    );

    //const updatedShoppingCart= data.filter(mobile => mobile.productName===name);
    this.setState({ productList: this.updatedMobileList, shoppingCart: cart });
  };
  render() {
    console.log(this.state.shoppingCart);
    return (
      <div className="container-fluid">
        <div className="row app">
          <div className="col-md-9 col-12">
            <h2>Product List</h2>
            <div className="row">
              {this.state.productList != null &&
                this.state.productList.map(mobile => {
                  return (
                    <div className="col-md-4" key={mobile.productName}>
                      <Product mobile={mobile} add={this.addToCart} />
                    </div>
                  );
                })}
            </div>
          </div>

          <div className="col-md-3">
            <h2>Shopping Cart</h2>
            <Cart
              product={this.state.shoppingCart}
              removePro={this.removeProduct}
            />
          </div>
        </div>
      </div>
    );
  }
}

export default App;
