import React, { Component } from "react";
import "./Cart.css";

class Cart extends Component {
  remove = mobile => {
    this.props.removePro(mobile);
  };
  render() {
    return (
      <div>
        {this.props.product.map(mobile => (
          <div className="card">
            <p>
              {mobile.productName}
              <button
                className="btn btn-danger remove"
                onClick={() => this.remove(mobile)}
              >
                Remove
              </button>
            </p>
          </div>
        ))}
      </div>
    );
  }
}

export default Cart;
