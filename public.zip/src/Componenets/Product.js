import React, { Component } from "react";
import "./Product.css";
class Product extends Component {
  add = () => {
    this.props.add(this.props.mobile);
  };
  render() {
    return (
      <div className="centre-align card">
        <p className="container">{this.props.mobile.productName}</p>

        <img src={this.props.mobile.productImage} className="image" />
        <div className="container">
          <p>${this.props.mobile.price}</p>
          <button className="btn btn-primary add-button" onClick={this.add}>
            Add to Cart
          </button>
        </div>
      </div>
    );
  }
}

export default Product;
